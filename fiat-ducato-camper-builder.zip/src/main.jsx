import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { TransformControls } from "three/examples/jsm/controls/TransformControls.js";
import "./style.css";

const INITIAL_ITEMS = [
  { id: "bed-1", type: "Bed", label: "Bed", x: -0.48, z: -1.35, w: 1.25, d: 1.9, h: 0.42, color: "#c6ad8d", material: "Wood" },
  { id: "kitchen-1", type: "Kitchen", label: "Kitchen unit", x: 0.55, z: -0.7, w: 0.55, d: 1.45, h: 0.9, color: "#b28a5b", material: "Wood" },
  { id: "bath-1", type: "Bathroom", label: "Bathroom / shower", x: 0.48, z: 1.35, w: 1.05, d: 1.0, h: 1.55, color: "#b7c5c9", material: "Light grey" },
  { id: "sofa-1", type: "Sofa", label: "Bench seat", x: -0.47, z: 0.75, w: 0.72, d: 1.15, h: 0.55, color: "#747b7c", material: "Fabric" },
  { id: "table-1", type: "Table", label: "Dining table", x: -0.02, z: 0.72, w: 0.62, d: 0.65, h: 0.68, color: "#c39a68", material: "Wood" },
  { id: "fridge-1", type: "Fridge", label: "Fridge", x: 0.52, z: -1.65, w: 0.45, d: 0.5, h: 0.75, color: "#b8bec2", material: "Metal" },
  { id: "storage-1", type: "Storage", label: "Storage cabinet", x: -0.48, z: -0.1, w: 0.55, d: 0.65, h: 0.65, color: "#b28a5b", material: "Wood" },
  { id: "battery-1", type: "Battery", label: "Battery system", x: 0.53, z: 0.2, w: 0.42, d: 0.48, h: 0.38, color: "#384b5b", material: "Metal" }
];

function App() {
  const mountRef = useRef(null);
  const threeRef = useRef({});
  const [items, setItems] = useState(INITIAL_ITEMS);
  const [selectedId, setSelectedId] = useState("bed-1");
  const [mode, setMode] = useState("translate");
  const [view, setView] = useState("3D View");
  const [exteriorColor, setExteriorColor] = useState("#f0f0ec");
  const [woodColor, setWoodColor] = useState("#b28a5b");
  const [status, setStatus] = useState("Ready");
  const [showRoof, setShowRoof] = useState(false);
  const [showMeasurements, setShowMeasurements] = useState(true);

  const selected = items.find(i => i.id === selectedId) || null;

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color("#d8e1e3");
    scene.fog = new THREE.Fog("#d8e1e3", 12, 28);

    const camera = new THREE.PerspectiveCamera(43, mount.clientWidth / mount.clientHeight, 0.1, 100);
    camera.position.set(5.8, 5.2, 7.2);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xffffff, 0x65717a, 2.0));
    const sun = new THREE.DirectionalLight(0xffffff, 2.3);
    sun.position.set(4, 9, 6);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    scene.add(sun);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(40, 40),
      new THREE.MeshStandardMaterial({ color: "#b9c6c2", roughness: 0.95 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.04;
    ground.receiveShadow = true;
    scene.add(ground);

    const grid = new THREE.GridHelper(10, 20, 0x8e9b9c, 0xaeb9b8);
    grid.position.y = -0.025;
    scene.add(grid);

    const van = new THREE.Group();
    scene.add(van);

    const bodyMat = new THREE.MeshStandardMaterial({ color: exteriorColor, metalness: 0.22, roughness: 0.38 });
    const trimMat = new THREE.MeshStandardMaterial({ color: "#252c31", metalness: 0.25, roughness: 0.55 });
    const glassMat = new THREE.MeshStandardMaterial({ color: "#283b48", metalness: 0.35, roughness: 0.22, transparent: true, opacity: 0.9 });
    const floorMat = new THREE.MeshStandardMaterial({ color: "#8c6b4c", roughness: 0.76 });
    const woodMat = new THREE.MeshStandardMaterial({ color: woodColor, roughness: 0.65 });
    const innerWallMat = new THREE.MeshStandardMaterial({ color: "#e7e3d9", roughness: 0.8 });

    function box(parent, name, size, pos, material, cast = true) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
      mesh.name = name;
      mesh.position.set(...pos);
      mesh.castShadow = cast;
      mesh.receiveShadow = true;
      parent.add(mesh);
      return mesh;
    }

    // Approximate L3H2 body: cabin/front is +Z; interior floor is exposed as a cutaway.
    box(van, "chassis", [1.95, 0.18, 5.9], [0, 0.28, 0], trimMat);
    box(van, "interior floor", [1.82, 0.12, 5.55], [0, 0.42, -0.1], floorMat);
    // Low side sills and cutaway exterior panels.
    box(van, "left sill", [0.12, 0.38, 5.75], [-0.99, 0.65, 0], bodyMat);
    box(van, "right sill", [0.12, 0.38, 5.75], [0.99, 0.65, 0], bodyMat);
    box(van, "rear panel", [1.98, 1.85, 0.12], [0, 1.38, -2.96], bodyMat);
    box(van, "front cabin hood", [1.9, 0.48, 0.92], [0, 1.05, 2.82], bodyMat);
    // Cab and windscreen
    box(van, "dashboard", [1.55, 0.35, 0.48], [0, 1.35, 2.43], trimMat);
    const windshield = box(van, "windshield", [1.58, 0.76, 0.06], [0, 1.95, 2.72], glassMat);
    windshield.rotation.x = -0.28;
    box(van, "driver seat", [0.52, 0.72, 0.52], [-0.48, 0.95, 1.95], trimMat);
    box(van, "passenger seat", [0.52, 0.72, 0.52], [0.48, 0.95, 1.95], trimMat);
    // Side body rails and roof ring to communicate the van shell while leaving interior visible.
    box(van, "left upper body", [0.12, 1.1, 5.6], [-0.99, 1.65, -0.08], bodyMat);
    box(van, "right upper body", [0.12, 1.1, 5.6], [0.99, 1.65, -0.08], bodyMat);
    box(van, "front roof header", [2.0, 0.16, 0.14], [0, 2.22, 2.55], bodyMat);
    box(van, "rear roof header", [2.0, 0.16, 0.14], [0, 2.22, -2.84], bodyMat);
    box(van, "left roof rail", [0.14, 0.14, 5.45], [-0.91, 2.22, -0.1], bodyMat);
    box(van, "right roof rail", [0.14, 0.14, 5.45], [0.91, 2.22, -0.1], bodyMat);
    // Windows
    box(van, "left window", [0.035, 0.47, 1.05], [-0.923, 1.68, 0.65], glassMat, false);
    box(van, "right window", [0.035, 0.47, 1.05], [0.923, 1.68, 0.65], glassMat, false);
    // Wheels
    const wheelMat = new THREE.MeshStandardMaterial({ color: "#171a1d", roughness: 0.9 });
    const rimMat = new THREE.MeshStandardMaterial({ color: "#9aa1a5", metalness: 0.65, roughness: 0.35 });
    [-1, 1].forEach(x => [-1.85, 1.85].forEach(z => {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.43, 0.43, 0.22, 32), wheelMat);
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(x * 0.99, 0.48, z);
      wheel.castShadow = true;
      van.add(wheel);
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.235, 24), rimMat);
      rim.rotation.z = Math.PI / 2;
      rim.position.set(x * 1.0, 0.48, z);
      van.add(rim);
    }));
    // Roof solar panels
    const solarMat = new THREE.MeshStandardMaterial({ color: "#1d3e57", metalness: 0.4, roughness: 0.25 });
    box(van, "solar panel 1", [0.7, 0.045, 1.1], [-0.4, 2.34, -0.75], solarMat);
    box(van, "solar panel 2", [0.7, 0.045, 1.1], [0.4, 2.34, -0.75], solarMat);

    const itemMeshes = new Map();
    function makeFurniture(item) {
      const group = new THREE.Group();
      group.name = item.id;
      const color = item.type === "Kitchen" || item.type === "Storage" ? woodColor : item.color;
      const mainMat = new THREE.MeshStandardMaterial({ color, roughness: item.type === "Fridge" ? 0.35 : 0.72, metalness: item.type === "Fridge" ? 0.35 : 0.05 });
      const dark = new THREE.MeshStandardMaterial({ color: "#343b3e", roughness: 0.8 });
      if (item.type === "Bed") {
        box(group, "bed base", [item.w, item.h * 0.55, item.d], [0, item.h * 0.27, 0], woodMat);
        box(group, "mattress", [item.w * 0.96, item.h * 0.45, item.d * 0.96], [0, item.h * 0.76, 0], new THREE.MeshStandardMaterial({ color: item.color, roughness: 0.95 }));
        box(group, "pillow", [item.w * 0.45, 0.08, 0.32], [0, item.h + 0.04, -item.d * 0.32], new THREE.MeshStandardMaterial({ color: "#e5dfd3", roughness: 1 }));
      } else if (item.type === "Bathroom") {
        box(group, "bathroom base", [item.w, 0.1, item.d], [0, 0.05, 0], innerWallMat);
        box(group, "bathroom back wall", [item.w, item.h, 0.06], [0, item.h/2, -item.d/2], innerWallMat);
        box(group, "bathroom side wall", [0.06, item.h, item.d], [item.w/2, item.h/2, 0], innerWallMat);
        box(group, "shower tray", [item.w*0.8, 0.08, item.d*0.8], [0, 0.13, 0], new THREE.MeshStandardMaterial({color:"#d9e0e0", roughness:0.3}));
        const toilet = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.28, 20), new THREE.MeshStandardMaterial({color:"#f5f4ee", roughness:0.25}));
        toilet.position.set(-item.w*0.18, 0.28, item.d*0.15); group.add(toilet);
      } else if (item.type === "Sofa") {
        box(group, "sofa base", [item.w, item.h*0.4, item.d], [0, item.h*0.2, 0], dark);
        box(group, "sofa cushion", [item.w*0.92, 0.14, item.d*0.9], [0, item.h*0.48, 0], mainMat);
        box(group, "sofa back", [item.w, item.h*0.75, 0.14], [0, item.h*0.62, -item.d*0.43], mainMat);
      } else if (item.type === "Table") {
        box(group, "table top", [item.w, 0.08, item.d], [0, item.h, 0], mainMat);
        [-1,1].forEach(x => [-1,1].forEach(z => box(group, "table leg", [0.055, item.h, 0.055], [x*item.w*0.42,item.h/2,z*item.d*0.42], dark)));
      } else if (item.type === "Kitchen") {
        box(group, "cabinet", [item.w, item.h*0.8, item.d], [0, item.h*0.4, 0], mainMat);
        box(group, "counter", [item.w*1.06, 0.07, item.d*1.03], [0, item.h*0.83, 0], new THREE.MeshStandardMaterial({color:"#d0b18a", roughness:0.5}));
        box(group, "sink", [item.w*0.55, 0.035, item.d*0.24], [0, item.h*0.88, -item.d*0.22], dark);
        box(group, "hob", [item.w*0.45, 0.025, item.d*0.23], [0, item.h*0.88, item.d*0.22], new THREE.MeshStandardMaterial({color:"#25292b", metalness:0.2}));
      } else if (item.type === "Fridge") {
        box(group, "fridge", [item.w, item.h, item.d], [0, item.h/2, 0], mainMat);
        box(group, "fridge handle", [0.025, item.h*0.45, 0.025], [item.w*0.38, item.h*0.58, item.d/2+0.015], dark);
      } else if (item.type === "Battery") {
        box(group, "battery case", [item.w, item.h, item.d], [0, item.h/2, 0], mainMat);
        box(group, "battery top", [item.w*0.7, 0.05, item.d*0.7], [0, item.h+0.025, 0], dark);
      } else {
        box(group, "storage cabinet", [item.w, item.h, item.d], [0, item.h/2, 0], mainMat);
        box(group, "cabinet door", [item.w*0.84, item.h*0.78, 0.025], [0, item.h*0.52, item.d/2+0.015], woodMat);
        box(group, "cabinet handle", [0.035, 0.12, 0.03], [item.w*0.25, item.h*0.55, item.d/2+0.04], dark);
      }
      group.position.set(item.x, 0.49, item.z);
      group.rotation.y = item.rotation || 0;
      group.userData.itemId = item.id;
      group.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      return group;
    }

    items.forEach(item => {
      const mesh = makeFurniture(item);
      van.add(mesh);
      itemMeshes.set(item.id, mesh);
    });

    if (showRoof) {
      const roof = box(van, "roof cover", [1.98, 0.1, 5.8], [0, 2.34, -0.05], bodyMat);
      roof.material = roof.material.clone(); roof.material.transparent = true; roof.material.opacity = 0.45;
    }

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.target.set(0, 1.0, 0);
    controls.maxPolarAngle = Math.PI * 0.49;
    controls.minDistance = 3.5;
    controls.maxDistance = 14;

    const transform = new TransformControls(camera, renderer.domElement);
    transform.setMode(mode);
    transform.setSize(0.7);
    transform.addEventListener("dragging-changed", e => { controls.enabled = !e.value; });
    // Commit gizmo changes into React state after the user finishes moving/scaling/rotating.
    transform.addEventListener("mouseUp", () => {
      const obj = transform.object;
      const id = obj?.userData?.itemId;
      if (!id) return;
      const pos = obj.position.clone();
      const scale = obj.scale.clone();
      const rotY = obj.rotation.y;
      setItems(old => old.map(item => item.id === id ? {
        ...item,
        x: Number(pos.x.toFixed(2)),
        z: Number(pos.z.toFixed(2)),
        w: Number((item.w * scale.x).toFixed(2)),
        d: Number((item.d * scale.z).toFixed(2)),
        h: Number((item.h * scale.y).toFixed(2)),
        rotation: Number(rotY.toFixed(3))
      } : item));
    });
    scene.add(transform);

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    function onPointerDown(e) {
      if (transform.dragging) return;
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const targets = [];
      itemMeshes.forEach(m => m.traverse(o => { if (o.isMesh) targets.push(o); }));
      const hits = raycaster.intersectObjects(targets, false);
      if (hits.length) {
        let obj = hits[0].object;
        while (obj && !obj.userData.itemId) obj = obj.parent;
        if (obj?.userData.itemId) {
          setSelectedId(obj.userData.itemId);
          transform.attach(obj);
        }
      }
    }
    renderer.domElement.addEventListener("pointerdown", onPointerDown);

    function updateSelection() {
      const mesh = itemMeshes.get(selectedId);
      if (mesh) transform.attach(mesh);
      else transform.detach();
    }
    updateSelection();

    let frame;
    function animate() {
      frame = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    }
    animate();

    const resize = () => {
      if (!mount.clientWidth || !mount.clientHeight) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(mount);

    threeRef.current = { scene, camera, renderer, controls, transform, van, itemMeshes, bodyMat, woodMat, ground, grid, resize, observer, setCameraView: (v) => {
      if (v === "Top View" || v === "Floor Plan") camera.position.set(0.1, 9, 0.1);
      else if (v === "Side View") camera.position.set(8.5, 3.0, 0);
      else camera.position.set(5.8, 5.2, 7.2);
      controls.target.set(0, 1, 0); controls.update();
    }};
    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      renderer.domElement.removeEventListener("pointerdown", onPointerDown);
      transform.dispose();
      controls.dispose();
      renderer.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
      scene.traverse(o => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach(m => m.dispose?.());
      });
    };
  }, [items, exteriorColor, woodColor, mode, selectedId, showRoof]);

  useEffect(() => {
    const t = threeRef.current;
    if (t.setCameraView) t.setCameraView(view);
  }, [view]);

  function addItem(type) {
    const defaults = {
      Bed: [1.25, 1.9, 0.42, "#c6ad8d"],
      Kitchen: [0.55, 1.35, 0.9, woodColor],
      Bathroom: [1.0, 1.0, 1.55, "#b7c5c9"],
      Sofa: [0.72, 1.15, 0.55, "#747b7c"],
      Table: [0.62, 0.65, 0.68, woodColor],
      Fridge: [0.45, 0.5, 0.75, "#b8bec2"],
      Storage: [0.55, 0.65, 0.65, woodColor],
      Battery: [0.42, 0.48, 0.38, "#384b5b"]
    }[type];
    const id = `${type.toLowerCase()}-${Date.now()}`;
    const item = { id, type, label: ({Bed:"Bed",Kitchen:"Kitchen unit",Bathroom:"Bathroom / shower",Sofa:"Bench seat",Table:"Dining table",Fridge:"Fridge",Storage:"Storage cabinet",Battery:"Battery system"})[type], x: 0, z: 0, w: defaults[0], d: defaults[1], h: defaults[2], color: defaults[3], material: "Wood" };
    setItems(old => [...old, item]);
    setSelectedId(id);
    setStatus(`${item.label} added`);
  }

  function updateSelected(key, value) {
    if (!selected) return;
    setItems(old => old.map(i => i.id === selected.id ? { ...i, [key]: value } : i));
  }

  function saveDesign() {
    const payload = { project: "Fiat Ducato L3 H2 Adventure", savedAt: new Date().toISOString(), items, exteriorColor, woodColor, showMeasurements };
    localStorage.setItem("ducato-camper-design", JSON.stringify(payload));
    setStatus("Design saved on this device");
  }

  function loadDesign() {
    const raw = localStorage.getItem("ducato-camper-design");
    if (!raw) { setStatus("No saved design found on this device"); return; }
    try {
      const data = JSON.parse(raw);
      setItems(data.items || INITIAL_ITEMS);
      setExteriorColor(data.exteriorColor || "#f0f0ec");
      setWoodColor(data.woodColor || "#b28a5b");
      setShowMeasurements(data.showMeasurements ?? true);
      setSelectedId(data.items?.[0]?.id || "bed-1");
      setStatus("Saved design loaded");
    } catch { setStatus("Could not load saved design"); }
  }

  function exportDesign() {
    const data = { project: "Fiat Ducato L3 H2 Adventure", units: "meters", items, exteriorColor, woodColor, savedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "fiat-ducato-camper-design.json"; a.click();
    URL.revokeObjectURL(url);
    setStatus("Design exported as JSON");
  }

  function resetDesign() {
    setItems(INITIAL_ITEMS);
    setSelectedId("bed-1");
    setStatus("Layout reset");
  }

  const itemTypes = [
    ["Bed", "Bed", "▰"], ["Kitchen", "Kitchen", "▤"], ["Bathroom", "Bathroom / shower", "▥"],
    ["Sofa", "Bench seat", "▰"], ["Table", "Dining table", "▦"], ["Fridge", "Fridge", "▯"],
    ["Storage", "Storage cabinet", "▤"], ["Battery", "Battery system", "▣"]
  ];

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand"><div className="brand-mark">FD</div><div><strong>DUCATO</strong><span>Camper Builder 3D</span></div></div>
        <div className="view-tabs">
          {["3D View", "Top View", "Side View", "Floor Plan"].map(v => <button key={v} className={view===v?"active":""} onClick={() => setView(v)}>{v}</button>)}
        </div>
        <div className="top-actions"><button onClick={saveDesign}>Save</button><button onClick={loadDesign}>Load</button><button onClick={exportDesign}>Export</button></div>
      </header>

      <main className="workspace">
        <aside className="left-panel">
          <div className="panel-heading">DESIGN TOOLS</div>
          <button className="nav-active">◈　Design</button>
          <button onClick={() => setView("Floor Plan")}>⌗　Layout / floor plan</button>
          <button onClick={() => addItem("Bed")}>▱　Sleeping</button>
          <button onClick={() => addItem("Kitchen")}>▤　Kitchen</button>
          <button onClick={() => addItem("Bathroom")}>▥　Bathroom</button>
          <button onClick={() => addItem("Battery")}>ϟ　Electrical</button>
          <button onClick={() => setShowRoof(v=>!v)}>{showRoof?"☑":"□"}　{showRoof?"Hide roof":"Show roof"}</button>
          <div className="side-note"><span className="green-dot"></span> Interactive 3D model</div>
        </aside>

        <section className="viewport-wrap">
          <div className="viewport" ref={mountRef}>
            <div className="viewport-label"><span className="live-dot"></span> FIAT DUCATO · L3 H2 · ADVENTURE</div>
            <div className="viewport-hint">Drag to orbit · Scroll to zoom · Select furniture to edit</div>
            {showMeasurements && <div className="dimension-tag length-tag">≈ 5.99 m exterior length</div>}
            <div className="viewport-bottom"><span>Interior cutaway view</span><span>Units: meters · Approximate prototype</span></div>
          </div>
          <div className="viewport-toolbar">
            <button onClick={() => setView("3D View")}>◉ 3D</button>
            <button onClick={() => setView("Top View")}>⌃ Top</button>
            <button onClick={() => setView("Side View")}>▰ Side</button>
            <button onClick={() => setView("Floor Plan")}>▦ Plan</button>
            <span className="toolbar-spacer"></span>
            <button onClick={() => setMode("translate")} className={mode==="translate"?"tool-active":""}>↔ Move</button>
            <button onClick={() => setMode("rotate")} className={mode==="rotate"?"tool-active":""}>⟳ Rotate</button>
            <button onClick={() => setMode("scale")} className={mode==="scale"?"tool-active":""}>⤢ Scale</button>
          </div>
        </section>

        <aside className="right-panel">
          <section className="panel-section">
            <div className="section-title"><h2>Vehicle</h2><span className="pill">L3 H2</span></div>
            <div className="vehicle-card"><div className="vehicle-icon">▰</div><div><strong>Fiat Ducato</strong><small>Long wheelbase · High roof</small></div></div>
            <div className="spec-grid">
              <div><span>Exterior length</span><strong>5,998 mm*</strong></div>
              <div><span>Exterior width</span><strong>2,050 mm*</strong></div>
              <div><span>Exterior height</span><strong>2,524 mm*</strong></div>
              <div><span>Wheelbase</span><strong>4,035 mm*</strong></div>
            </div>
            <p className="tiny-note">*Illustrative figures; verify your exact model year/variant.</p>
          </section>

          <section className="panel-section">
            <div className="section-title"><h2>Add items</h2><span className="count">{items.length}</span></div>
            <div className="item-grid">
              {itemTypes.map(([type,label,icon]) => <button className="item-button" key={type} onClick={() => addItem(type)}><span className="item-icon">{icon}</span><span>{label}</span><small>+ Add</small></button>)}
            </div>
          </section>

          <section className="panel-section">
            <div className="section-title"><h2>Materials & colors</h2></div>
            <label className="field-label">Cabinet / wood finish</label>
            <div className="swatches">
              {[["Oak","#b28a5b"],["Walnut","#76543b"],["Light wood","#d1b991"],["White","#e9e7df"]].map(([name,color]) => <button key={name} className={`swatch ${woodColor===color?"selected":""}`} title={name} style={{background:color}} onClick={() => {setWoodColor(color);setItems(old=>old.map(i=>["Kitchen","Storage"].includes(i.type)?{...i,color}:i));}} />)}
            </div>
            <label className="field-label">Exterior color</label>
            <div className="swatches">
              {[["White","#f0f0ec"],["Silver","#aeb7bc"],["Graphite","#42484b"],["Blue","#1767a7"],["Sand","#c6b69b"]].map(([name,color]) => <button key={name} className={`swatch ${exteriorColor===color?"selected":""}`} title={name} style={{background:color}} onClick={() => setExteriorColor(color)} />)}
            </div>
          </section>

          <section className="panel-section editor">
            <div className="section-title"><h2>Selected item</h2><span className="pill">{selected?.type || "None"}</span></div>
            {!selected ? <p className="empty-state">Select an item in the model or list.</p> : <>
              <div className="selected-name">{selected.label}</div>
              <div className="edit-grid">
                {[["x","Position X"],["z","Position Z"],["w","Width"],["d","Depth"],["h","Height"]].map(([key,label]) => <label key={key} className="edit-field"><span>{label} (m)</span><input type="number" step="0.05" value={Number(selected[key]).toFixed(2)} onChange={e=>updateSelected(key, Number(e.target.value))}/></label>)}
              </div>
              <label className="field-label">Item color</label>
              <input className="color-input" type="color" value={selected.color} onChange={e=>updateSelected("color",e.target.value)} />
              <div className="editor-actions">
                <button onClick={() => {setItems(old=>old.filter(i=>i.id!==selected.id));setSelectedId(items.find(i=>i.id!==selected.id)?.id||"");}}>Delete item</button>
                <button className="primary" onClick={saveDesign}>Save layout</button>
              </div>
            </>}
          </section>
          <section className="panel-section">
            <div className="section-title"><h2>Project</h2></div>
            <label className="toggle-row"><span>Show measurements</span><input type="checkbox" checked={showMeasurements} onChange={e=>setShowMeasurements(e.target.checked)}/></label>
            <div className="editor-actions"><button onClick={resetDesign}>Reset layout</button><button onClick={exportDesign}>Export JSON</button></div>
          </section>
        </aside>
      </main>
      <footer className="statusbar"><span><i className="green-dot"></i>{status}</span><span>Prototype 1.0 · Designed for touch and desktop</span></footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
