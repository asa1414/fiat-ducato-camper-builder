# Fiat Ducato Camper Builder 3D

A mobile-friendly React + Three.js prototype for planning an approximate Fiat Ducato L3 H2 Adventure camper conversion.

## Features in this prototype
- Orbit camera with zoom and pan
- 3D cutaway van shell and furniture blocks
- Add bed, kitchen, bathroom/shower, sofa, table, fridge, storage and battery system
- Select furniture by tapping/clicking it in the model
- Move, rotate and scale selected furniture using 3D gizmos
- Numeric position and size editing
- Exterior and wood finish swatches; per-item color picker
- Top, side, floor plan and 3D views
- Save/load on the current browser/device with localStorage
- Export a JSON layout file

## Important limitations
This is a functional prototype, not an engineering-certified vehicle plan. Vehicle dimensions are illustrative and vary by model year and configuration. Furniture collision checks, wall-clearance rules, exact vehicle shell geometry, plumbing/electrical calculations, cloud sync, and account-based storage are not implemented. Local save data stays in the browser/device where it was saved.

## Run locally
Install Node.js (18+ recommended), then:

```bash
npm install
npm run dev
```

Open the local address shown by Vite.

## Deploy to Vercel
1. Create a GitHub repository and upload all project files.
2. Sign in to Vercel at https://vercel.com.
3. Choose **Add New → Project**, import the GitHub repository.
4. Framework preset: **Vite** (usually detected automatically).
5. Build command: `npm run build`
6. Output directory: `dist`
7. Click **Deploy**.

No API keys are needed for this prototype.
